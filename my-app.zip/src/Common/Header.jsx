import React from "react";

const Header = ({ value }) => {
  return <h1 class="display-1">{value}</h1>;
};

export default Header;
